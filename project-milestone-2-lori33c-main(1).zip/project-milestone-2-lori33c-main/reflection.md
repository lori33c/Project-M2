# Milestone 2

## Description
Describe what you did for this milestone in your own words.

## Challenges encountered
Describe the challenges you encountered while working on this milestone of the project.

## Things I've learned
What is the most important thing you've learned from this milestone in the project?
